package exercicio01;

public class AulaPoo {

    public String nome;
    public int idade;
    public double alvo;
    public double contr;


}
